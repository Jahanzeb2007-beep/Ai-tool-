import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Linking,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { colors, radius } from '../theme';
import { PROVIDERS } from '../api';
import { getApiKey, saveApiKey, removeApiKey } from '../storage';

function KeyField({ providerId }) {
  const provider = PROVIDERS[providerId];
  const [value, setValue] = useState('');
  const [savedValue, setSavedValue] = useState('');
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState(null); // { type: 'ok' | 'error', text }

  useEffect(() => {
    let active = true;
    getApiKey(providerId).then((key) => {
      if (!active) return;
      setValue(key);
      setSavedValue(key);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [providerId]);

  const handleSave = async () => {
    const trimmed = value.trim();
    if (!trimmed) {
      setStatus({ type: 'error', text: 'Enter a key first, or use Remove to clear it.' });
      return;
    }
    try {
      await saveApiKey(providerId, trimmed);
      setValue(trimmed);
      setSavedValue(trimmed);
      setStatus({ type: 'ok', text: 'Key saved on this device.' });
    } catch (e) {
      setStatus({ type: 'error', text: 'Could not save the key. Try again.' });
    }
  };

  const handleRemove = async () => {
    try {
      await removeApiKey(providerId);
      setValue('');
      setSavedValue('');
      setStatus({ type: 'ok', text: 'Key removed.' });
    } catch (e) {
      setStatus({ type: 'error', text: 'Could not remove the key. Try again.' });
    }
  };

  const openHelp = () => {
    Linking.openURL(provider.helpUrl).catch(() => {
      setStatus({ type: 'error', text: `Could not open ${provider.helpUrl}` });
    });
  };

  const hasSaved = savedValue.length > 0;
  const changed = value.trim() !== savedValue;

  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitle}>{provider.name}</Text>
        <Text style={[styles.badge, hasSaved ? styles.badgeOn : styles.badgeOff]}>
          {hasSaved ? 'Key saved' : 'No key'}
        </Text>
      </View>

      {loading ? (
        <ActivityIndicator color={colors.accent} style={styles.loader} />
      ) : (
        <>
          <View style={styles.inputWrap}>
            <TextInput
              style={styles.input}
              value={value}
              onChangeText={(t) => {
                setValue(t);
                setStatus(null);
              }}
              placeholder={provider.placeholder}
              placeholderTextColor={colors.textDim}
              secureTextEntry={!visible}
              autoCapitalize="none"
              autoCorrect={false}
              spellCheck={false}
            />
            <TouchableOpacity onPress={() => setVisible((v) => !v)} style={styles.showButton}>
              <Text style={styles.showText}>{visible ? 'Hide' : 'Show'}</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.actions}>
            <TouchableOpacity
              style={[styles.saveButton, !changed && styles.saveDisabled]}
              onPress={handleSave}
              disabled={!changed}
              activeOpacity={0.8}
            >
              <Text style={styles.saveText}>Save key</Text>
            </TouchableOpacity>
            {hasSaved ? (
              <TouchableOpacity style={styles.removeButton} onPress={handleRemove} activeOpacity={0.8}>
                <Text style={styles.removeText}>Remove</Text>
              </TouchableOpacity>
            ) : null}
          </View>

          {status ? (
            <Text style={[styles.status, status.type === 'ok' ? styles.statusOk : styles.statusError]}>
              {status.text}
            </Text>
          ) : null}

          <TouchableOpacity onPress={openHelp}>
            <Text style={styles.link}>Get a free {provider.name} key</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

export default function SettingsScreen() {
  return (
    <ScrollView
      style={styles.flex}
      contentContainerStyle={styles.content}
      keyboardShouldPersistTaps="handled"
    >
      <Text style={styles.intro}>
        Keys stay on this device and are sent only to the provider you chat with. Nothing goes
        through any other server.
      </Text>

      <KeyField providerId="gemini" />
      <KeyField providerId="groq" />

      <Text style={styles.note}>
        Keys are stored with AsyncStorage, which is not encrypted. Don't use this on a shared
        device, and create keys you can revoke at any time.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  intro: {
    color: colors.textDim,
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 16,
    marginBottom: 14,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  cardTitle: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
  },
  badge: {
    fontSize: 12,
    fontWeight: '600',
    paddingVertical: 3,
    paddingHorizontal: 10,
    borderRadius: radius.lg,
    overflow: 'hidden',
  },
  badgeOn: {
    color: colors.accent,
    backgroundColor: 'rgba(111,214,194,0.12)',
  },
  badgeOff: {
    color: colors.textDim,
    backgroundColor: colors.surfaceHigh,
  },
  loader: {
    paddingVertical: 20,
  },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.bg,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  input: {
    flex: 1,
    color: colors.text,
    fontSize: 15,
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  showButton: {
    paddingHorizontal: 12,
    paddingVertical: 12,
  },
  showText: {
    color: colors.accent,
    fontSize: 14,
    fontWeight: '600',
  },
  actions: {
    flexDirection: 'row',
    marginTop: 12,
  },
  saveButton: {
    backgroundColor: colors.accent,
    borderRadius: radius.sm,
    paddingVertical: 10,
    paddingHorizontal: 18,
  },
  saveDisabled: {
    opacity: 0.35,
  },
  saveText: {
    color: '#0B1512',
    fontWeight: '700',
    fontSize: 14,
  },
  removeButton: {
    marginLeft: 10,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  removeText: {
    color: colors.text,
    fontSize: 14,
  },
  status: {
    marginTop: 10,
    fontSize: 14,
  },
  statusOk: { color: colors.accent },
  statusError: { color: colors.danger },
  link: {
    color: colors.textDim,
    fontSize: 14,
    marginTop: 14,
    textDecorationLine: 'underline',
  },
  note: {
    color: colors.textDim,
    fontSize: 13,
    lineHeight: 19,
    marginTop: 4,
  },
});
