import { getApiKey } from './storage';

export const PROVIDERS = {
  gemini: {
    name: 'Google Gemini',
    placeholder: 'AIza...',
    helpUrl: 'https://aistudio.google.com/apikey',
  },
  groq: {
    name: 'Groq',
    placeholder: 'gsk_...',
    helpUrl: 'https://console.groq.com/keys',
  },
};

export const MODELS = [
  {
    id: 'gemini-flash',
    label: 'Gemini Flash',
    provider: 'gemini',
    model: 'gemini-flash-latest',
    maker: 'Google',
  },
  {
    id: 'groq-llama-70b',
    label: 'Llama 3.3 70B',
    provider: 'groq',
    model: 'llama-3.3-70b-versatile',
    maker: 'Groq',
  },
  {
    id: 'groq-llama-8b',
    label: 'Llama 3.1 8B Instant',
    provider: 'groq',
    model: 'llama-3.1-8b-instant',
    maker: 'Groq',
  },
];

export function getModel(modelId) {
  return MODELS.find((m) => m.id === modelId) || MODELS[0];
}

export class AiError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'AiError';
    this.code = code;
  }
}

const SYSTEM_PROMPT =
  'You are a helpful, concise assistant. Use plain text and short paragraphs. Avoid heavy markdown.';

const TIMEOUT_MS = 45000;

function describeHttpError(status, apiMessage, providerName) {
  const detail = apiMessage ? ` (${apiMessage})` : '';
  const looksLikeKeyProblem = /api key|api_key|invalid key|unauthor|permission/i.test(apiMessage || '');

  if (status === 401 || status === 403 || (status === 400 && looksLikeKeyProblem)) {
    return new AiError(
      'INVALID_KEY',
      `${providerName} rejected your API key. Check it in Settings and save it again.${detail}`
    );
  }
  if (status === 429) {
    return new AiError(
      'RATE_LIMIT',
      `${providerName} rate limit reached. Wait a minute and try again, or switch models.${detail}`
    );
  }
  if (status === 404) {
    return new AiError(
      'MODEL_NOT_FOUND',
      `${providerName} could not find this model. It may have been renamed or retired. Pick another model.${detail}`
    );
  }
  if (status >= 500) {
    return new AiError(
      'SERVER',
      `${providerName} is having trouble right now. Try again shortly.${detail}`
    );
  }
  return new AiError('HTTP', `${providerName} returned an error (${status}).${detail}`);
}

async function request(url, options, providerName) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  let response;
  try {
    response = await fetch(url, { ...options, signal: controller.signal });
  } catch (e) {
    if (e && e.name === 'AbortError') {
      throw new AiError('TIMEOUT', `${providerName} took too long to respond. Try again.`);
    }
    throw new AiError('NETWORK', 'Could not reach the server. Check your internet connection.');
  } finally {
    clearTimeout(timer);
  }

  const raw = await response.text();
  let data = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch (e) {
    data = null;
  }

  if (!response.ok) {
    const apiMessage = data && data.error && data.error.message ? data.error.message : '';
    throw describeHttpError(response.status, apiMessage, providerName);
  }

  return data;
}

async function callGemini(apiKey, modelName, history) {
  const contents = history.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.text }],
  }));

  const data = await request(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
      }),
    },
    PROVIDERS.gemini.name
  );

  if (data && data.promptFeedback && data.promptFeedback.blockReason) {
    throw new AiError(
      'BLOCKED',
      `Gemini blocked this prompt (${data.promptFeedback.blockReason}). Try rephrasing.`
    );
  }

  const candidate = data && data.candidates && data.candidates[0];
  const parts = candidate && candidate.content && candidate.content.parts;
  const text = parts ? parts.map((p) => p.text || '').join('').trim() : '';

  if (!text) {
    const reason = candidate && candidate.finishReason ? ` (${candidate.finishReason})` : '';
    throw new AiError('EMPTY', `Gemini returned an empty reply${reason}. Try again.`);
  }
  return text;
}

async function callGroq(apiKey, modelName, history) {
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...history.map((m) => ({ role: m.role, content: m.text })),
  ];

  const data = await request(
    'https://api.groq.com/openai/v1/chat/completions',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: modelName,
        messages,
        temperature: 0.7,
      }),
    },
    PROVIDERS.groq.name
  );

  const choice = data && data.choices && data.choices[0];
  const text = choice && choice.message && choice.message.content ? choice.message.content.trim() : '';

  if (!text) {
    throw new AiError('EMPTY', 'Groq returned an empty reply. Try again.');
  }
  return text;
}

/**
 * Sends the conversation to the selected model and returns the reply text.
 * history: array of { role: 'user' | 'assistant', text: string }
 * Throws AiError with a user-friendly message and a machine-readable code.
 */
export async function sendMessage(modelId, history) {
  const config = getModel(modelId);
  const providerName = PROVIDERS[config.provider].name;
  const apiKey = await getApiKey(config.provider);

  if (!apiKey) {
    throw new AiError(
      'MISSING_KEY',
      `No ${providerName} API key found. Add one in Settings to use ${config.label}.`
    );
  }

  if (config.provider === 'gemini') {
    return callGemini(apiKey, config.model, history);
  }
  return callGroq(apiKey, config.model, history);
}
