import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { colors, radius } from '../theme';
import { sendMessage, getModel } from '../api';

let idCounter = 0;
const nextId = () => {
  idCounter += 1;
  return `${Date.now()}-${idCounter}`;
};

function Bubble({ message, onOpenSettings }) {
  const isUser = message.role === 'user';

  if (message.isError) {
    return (
      <View style={[styles.row, styles.rowLeft]}>
        <View style={[styles.bubble, styles.errorBubble]}>
          <Text style={styles.errorText} selectable>
            {message.text}
          </Text>
          {message.errorCode === 'MISSING_KEY' || message.errorCode === 'INVALID_KEY' ? (
            <TouchableOpacity onPress={onOpenSettings} style={styles.errorAction}>
              <Text style={styles.errorActionText}>Open Settings</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.row, isUser ? styles.rowRight : styles.rowLeft]}>
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
        {!isUser && message.modelLabel ? (
          <Text style={styles.modelTag}>{message.modelLabel}</Text>
        ) : null}
        <Text style={styles.bubbleText} selectable>
          {message.text}
        </Text>
      </View>
    </View>
  );
}

export default function ChatScreen({ messages, setMessages, selectedModelId, onOpenSettings }) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const listRef = useRef(null);

  const scrollToBottom = () => {
    if (listRef.current) {
      listRef.current.scrollToEnd({ animated: true });
    }
  };

  const handleSend = async () => {
    const text = input.trim();
    if (!text || loading) return;

    const model = getModel(selectedModelId);
    const userMessage = { id: nextId(), role: 'user', text };

    // Error bubbles are display-only and never sent back to the model.
    const history = [...messages, userMessage]
      .filter((m) => !m.isError)
      .map((m) => ({ role: m.role, text: m.text }));

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const reply = await sendMessage(model.id, history);
      setMessages((prev) => [
        ...prev,
        { id: nextId(), role: 'assistant', text: reply, modelLabel: model.label },
      ]);
    } catch (e) {
      setMessages((prev) => [
        ...prev,
        {
          id: nextId(),
          role: 'assistant',
          isError: true,
          errorCode: e && e.code ? e.code : 'UNKNOWN',
          text: e && e.message ? e.message : 'Something went wrong. Please try again.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => setMessages([]);

  const canSend = input.trim().length > 0 && !loading;

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 8 : 0}
    >
      <FlatList
        ref={listRef}
        style={styles.flex}
        contentContainerStyle={styles.listContent}
        data={messages}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <Bubble message={item} onOpenSettings={onOpenSettings} />}
        onContentSizeChange={scrollToBottom}
        onLayout={scrollToBottom}
        keyboardShouldPersistTaps="handled"
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>Ask anything</Text>
            <Text style={styles.emptyBody}>
              Pick a model at the top, then type below. Add your API keys in Settings first.
            </Text>
          </View>
        }
        ListFooterComponent={
          loading ? (
            <View style={[styles.row, styles.rowLeft]}>
              <View style={[styles.bubble, styles.aiBubble, styles.typing]}>
                <ActivityIndicator size="small" color={colors.accent} />
                <Text style={styles.typingText}>{getModel(selectedModelId).label} is thinking…</Text>
              </View>
            </View>
          ) : null
        }
      />

      {messages.length > 0 ? (
        <TouchableOpacity onPress={clearChat} style={styles.clearButton} disabled={loading}>
          <Text style={styles.clearText}>Clear chat</Text>
        </TouchableOpacity>
      ) : null}

      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Message"
          placeholderTextColor={colors.textDim}
          multiline
          maxLength={8000}
          editable={!loading}
        />
        <TouchableOpacity
          style={[styles.sendButton, !canSend && styles.sendDisabled]}
          onPress={handleSend}
          disabled={!canSend}
          activeOpacity={0.8}
        >
          <Text style={styles.sendText}>Send</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  listContent: {
    padding: 14,
    paddingBottom: 8,
    flexGrow: 1,
  },
  row: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  rowLeft: { justifyContent: 'flex-start' },
  rowRight: { justifyContent: 'flex-end' },
  bubble: {
    maxWidth: '85%',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: radius.lg,
  },
  userBubble: {
    backgroundColor: colors.userBubble,
    borderBottomRightRadius: 6,
  },
  aiBubble: {
    backgroundColor: colors.aiBubble,
    borderBottomLeftRadius: 6,
    borderWidth: 1,
    borderColor: colors.border,
  },
  errorBubble: {
    backgroundColor: colors.dangerBg,
    borderWidth: 1,
    borderColor: colors.danger,
    borderBottomLeftRadius: 6,
  },
  errorText: {
    color: colors.danger,
    fontSize: 15,
    lineHeight: 21,
  },
  errorAction: {
    marginTop: 10,
    alignSelf: 'flex-start',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: radius.sm,
    borderWidth: 1,
    borderColor: colors.danger,
  },
  errorActionText: {
    color: colors.danger,
    fontWeight: '600',
    fontSize: 14,
  },
  modelTag: {
    color: colors.accent,
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
  },
  bubbleText: {
    color: colors.text,
    fontSize: 16,
    lineHeight: 23,
  },
  typing: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  typingText: {
    color: colors.textDim,
    marginLeft: 10,
    fontSize: 14,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
    paddingVertical: 80,
  },
  emptyTitle: {
    color: colors.text,
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 8,
  },
  emptyBody: {
    color: colors.textDim,
    fontSize: 15,
    lineHeight: 22,
    textAlign: 'center',
  },
  clearButton: {
    alignSelf: 'center',
    paddingVertical: 4,
    paddingHorizontal: 12,
  },
  clearText: {
    color: colors.textDim,
    fontSize: 13,
  },
  inputBar: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.bg,
  },
  input: {
    flex: 1,
    maxHeight: 130,
    minHeight: 44,
    backgroundColor: colors.surface,
    color: colors.text,
    fontSize: 16,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 16,
    paddingTop: Platform.OS === 'ios' ? 12 : 10,
    paddingBottom: Platform.OS === 'ios' ? 12 : 10,
  },
  sendButton: {
    marginLeft: 8,
    height: 44,
    paddingHorizontal: 18,
    borderRadius: radius.lg,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendDisabled: {
    opacity: 0.35,
  },
  sendText: {
    color: '#0B1512',
    fontSize: 15,
    fontWeight: '700',
  },
});
