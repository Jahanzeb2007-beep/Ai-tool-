export const colors = {
  bg: '#10121A',
  surface: '#181B26',
  surfaceHigh: '#222638',
  border: '#2B3042',
  text: '#E8EAF2',
  textDim: '#8B91A7',
  userBubble: '#4A63E0',
  aiBubble: '#1E2231',
  accent: '#6FD6C2',
  danger: '#F0716F',
  dangerBg: '#2C1A20',
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
};
