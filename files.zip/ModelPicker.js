import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, Pressable, StyleSheet } from 'react-native';
import { colors, radius } from '../theme';
import { MODELS, getModel } from '../api';

export default function ModelPicker({ selectedId, onSelect }) {
  const [open, setOpen] = useState(false);
  const current = getModel(selectedId);

  const choose = (id) => {
    setOpen(false);
    onSelect(id);
  };

  return (
    <View>
      <TouchableOpacity style={styles.button} onPress={() => setOpen(true)} activeOpacity={0.8}>
        <Text style={styles.buttonText} numberOfLines={1}>
          {current.label}
        </Text>
        <Text style={styles.caret}>▾</Text>
      </TouchableOpacity>

      <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
        <Pressable style={styles.backdrop} onPress={() => setOpen(false)}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>Choose a model</Text>
            {MODELS.map((m) => {
              const active = m.id === selectedId;
              return (
                <TouchableOpacity
                  key={m.id}
                  style={[styles.option, active && styles.optionActive]}
                  onPress={() => choose(m.id)}
                  activeOpacity={0.8}
                >
                  <View style={styles.optionTextWrap}>
                    <Text style={styles.optionLabel}>{m.label}</Text>
                    <Text style={styles.optionMaker}>via {m.maker}</Text>
                  </View>
                  {active ? <Text style={styles.check}>✓</Text> : null}
                </TouchableOpacity>
              );
            })}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surfaceHigh,
    borderRadius: radius.lg,
    paddingVertical: 8,
    paddingHorizontal: 14,
    maxWidth: 220,
  },
  buttonText: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
    flexShrink: 1,
  },
  caret: {
    color: colors.textDim,
    fontSize: 14,
    marginLeft: 8,
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-start',
    paddingTop: 90,
    paddingHorizontal: 16,
  },
  sheet: {
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 8,
  },
  sheetTitle: {
    color: colors.textDim,
    fontSize: 13,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: radius.sm,
  },
  optionActive: {
    backgroundColor: colors.surfaceHigh,
  },
  optionTextWrap: {
    flex: 1,
  },
  optionLabel: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '600',
  },
  optionMaker: {
    color: colors.textDim,
    fontSize: 13,
    marginTop: 2,
  },
  check: {
    color: colors.accent,
    fontSize: 18,
    fontWeight: '700',
  },
});
