import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  SafeAreaView,
  Platform,
  StatusBar as RNStatusBar,
  StyleSheet,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { colors } from './theme';
import { MODELS } from './api';
import { getSelectedModel, saveSelectedModel } from './storage';
import ModelPicker from './components/ModelPicker';
import ChatScreen from './components/ChatScreen';
import SettingsScreen from './components/SettingsScreen';

export default function App() {
  const [screen, setScreen] = useState('chat'); // 'chat' | 'settings'
  const [selectedModelId, setSelectedModelId] = useState(MODELS[0].id);
  const [messages, setMessages] = useState([]);

  // Restore the last used model.
  useEffect(() => {
    let active = true;
    getSelectedModel().then((id) => {
      if (active && id && MODELS.some((m) => m.id === id)) {
        setSelectedModelId(id);
      }
    });
    return () => {
      active = false;
    };
  }, []);

  const handleSelectModel = (id) => {
    setSelectedModelId(id);
    saveSelectedModel(id);
  };

  const inSettings = screen === 'settings';

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />

      <View style={styles.header}>
        {inSettings ? (
          <>
            <TouchableOpacity onPress={() => setScreen('chat')} style={styles.headerButton}>
              <Text style={styles.headerButtonText}>‹ Back</Text>
            </TouchableOpacity>
            <Text style={styles.title}>Settings</Text>
            <View style={styles.headerSpacer} />
          </>
        ) : (
          <>
            <ModelPicker selectedId={selectedModelId} onSelect={handleSelectModel} />
            <TouchableOpacity onPress={() => setScreen('settings')} style={styles.headerButton}>
              <Text style={styles.headerButtonText}>Settings</Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      {/* Chat stays mounted so an in-flight reply is never lost when opening Settings. */}
      <View style={[styles.body, inSettings && styles.hidden]}>
        <ChatScreen
          messages={messages}
          setMessages={setMessages}
          selectedModelId={selectedModelId}
          onOpenSettings={() => setScreen('settings')}
        />
      </View>

      {inSettings ? (
        <View style={styles.body}>
          <SettingsScreen />
        </View>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.bg,
    paddingTop: Platform.OS === 'android' ? RNStatusBar.currentHeight || 0 : 0,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  title: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '700',
  },
  headerButton: {
    paddingVertical: 8,
    paddingHorizontal: 6,
  },
  headerButtonText: {
    color: colors.accent,
    fontSize: 15,
    fontWeight: '600',
  },
  headerSpacer: {
    width: 56,
  },
  body: {
    flex: 1,
  },
  hidden: {
    display: 'none',
  },
});
