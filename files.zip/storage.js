import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY_PREFIX = '@ai_hub_api_key_';
const MODEL_KEY = '@ai_hub_selected_model';

export async function saveApiKey(provider, key) {
  await AsyncStorage.setItem(KEY_PREFIX + provider, key.trim());
}

export async function getApiKey(provider) {
  try {
    const value = await AsyncStorage.getItem(KEY_PREFIX + provider);
    return value ? value.trim() : '';
  } catch (e) {
    return '';
  }
}

export async function removeApiKey(provider) {
  await AsyncStorage.removeItem(KEY_PREFIX + provider);
}

export async function saveSelectedModel(modelId) {
  try {
    await AsyncStorage.setItem(MODEL_KEY, modelId);
  } catch (e) {
    // Non-critical: the app still works, the choice just isn't remembered.
  }
}

export async function getSelectedModel() {
  try {
    return await AsyncStorage.getItem(MODEL_KEY);
  } catch (e) {
    return null;
  }
}
